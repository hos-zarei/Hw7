// hosein zarei 40223038
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    int wordnum, i, j, k;
    printf("the number of words: ");
    scanf("%d", &wordnum);

    char lang1[wordnum][100];
    char lang2[wordnum][100];
    char lang1_in[wordnum][100];
    char lang2_in[wordnum][100];
    for (i = 0; i < wordnum; i++)
    {
        printf("word lang 1: ");
        scanf("%s", lang1_in[i]);
        printf("word lang 2: ");
        scanf("%s", lang2_in[i]);
    }
    for (int i = 0; i < wordnum; i++)
    {
        for (int j = 0; j <= strlen(lang1_in[i]); j++)
        {
            lang1[i][j] = tolower(lang1_in[i][j]);
        }
        for (int j = 0; j <= strlen(lang2_in[i]); j++)
        {
            lang2[i][j] = tolower(lang2_in[i][j]);
        }
    }
    char sentence[1000];
    printf("pleas input a sentence: ");
    getchar();
    scanf("%[^\n]s", sentence);

    char javab[1000] = "";
    for (int i = 0; i < 1000; i++)
    {
        javab[i] = 0;
    }
    int sentence_index = 0;
    while (sentence[sentence_index] != '\0')
    {
        char word[100] = "";
        int wordindex = 0;
        while ((sentence[sentence_index] != ' ') && sentence[sentence_index] != '\0')
        {
            word[wordindex++] = sentence[sentence_index++];
        }
        word[wordindex] = '\0';

        for (int i = 0; i <= strlen(word) + 1; i++)
        {
            word[i] = tolower(word[i]);
        }

        int found = 0;

        for (i = 0; i < wordnum; i++)
        {
            int isequal = strcmp(lang1[i], word);
            if (!isequal && strlen(lang2[i]) < strlen(lang1[i]))
            {
                strcat(javab, lang2_in[i]);
                found = 1;
                break;
            }
            isequal = strcmp(lang2[i], word);
            if (!isequal && strlen(lang1[i]) < strlen(lang2[i]))
            {
                strcat(javab, lang1_in[i]);
                found = 1;
                break;
            }
        }
        if (!found)
        {
            strcat(javab, word);
        }
        if (sentence[sentence_index] == ' ')
        {
            strcat(javab, " ");
        }
        sentence_index++;
    }

    printf("%s\n", javab);

    return 0;
}